# a4adiags 0.2.0

## BUG FIXES

- plotRunsTest now does the right calculations for age-disaggregated indices.

## NEW FEATURES

- plotRunsTest(FLQuant, FLQuant)

# a4adiags 0.1.0

- First beta version, contains methods for runs test and cross-validation by
  retrospective hindcasting
