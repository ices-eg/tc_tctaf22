#' @param object object of relevant class (see signature of method)


