#' @section Constructor:
#' A constructor method exists for this class that can take named arguments for
#' any of the list elements.
#' @param object unnamed object to be added to the list
#' @param ... other named or unnamed objects
