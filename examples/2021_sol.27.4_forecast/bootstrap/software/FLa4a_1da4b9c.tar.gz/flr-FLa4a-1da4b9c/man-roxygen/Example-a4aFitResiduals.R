#' @examples
#' flqs <- residuals(obj, ple4, FLIndices(idx=ple4.index))

