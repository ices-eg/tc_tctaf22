#' @description
#' Class definition (slots), constructors, accessors, replacement (when relevant) and common methods.  
