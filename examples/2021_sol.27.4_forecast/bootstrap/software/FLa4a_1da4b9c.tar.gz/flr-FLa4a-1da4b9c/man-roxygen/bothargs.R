#' @param object object of relevant class (see signature of method)
#' @param ... additional argument list that might never be used

